package Ball_Game_V2;

public class Test {

    public static void main(String[] args) {
        Team team=new Team(4);
        team.play();

    }

}
