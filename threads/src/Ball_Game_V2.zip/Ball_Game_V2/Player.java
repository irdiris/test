package Ball_Game_V2;



public class Player extends Thread {
    private Team team;
    private int PlayerID;
    private boolean Hasball;
    private boolean Gameover;
    private int round;
   
    
    public Player(Team team, int PlayerID) {
    	this.team=team; 
    	this.PlayerID=PlayerID;
    	Hasball=false;
    	Gameover=false;
    	round=0;
    }
  public void Throw() {
	  System.out.println("Player "+PlayerID+": threw the ball!");
	  Hasball=false;
  }
  public void Throwback() {
	  System.out.println("Player "+PlayerID+": threw the ball back!");
	  Hasball=false;
  }
  public void Catch() {
	  System.out.println("Player "+PlayerID+": got the ball!");
	  Hasball=true;
  }
  public void endgame() {
	  Gameover=true;
  }
    public void State() {
    	System.out.println("Player"+PlayerID+ (Hasball? "has ball!": "doesn't have ball."));
    }
    public void shoot() {
    	Hasball=false;
    	System.out.println("Player "+PlayerID+": Shoots the ball!");
    }
    
@Override
public void run() { while (!Gameover) {
	while (round<10) {
		   synchronized (team) {
			   
		if(Hasball) {
			if(team.forward()) {
			Throw();
			try {
				currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Player nextPlayer= team.getPlayer(PlayerID);
			nextPlayer.Catch();
			team.notifyAll();
			}else {
				if(PlayerID!=1) {
				Throwback();
				try {
					currentThread().sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Player nextPlayer= team.getPlayer(PlayerID);
				nextPlayer.Catch();
				team.notifyAll();}
				else{
					shoot();
					Catch();
					Throw();
					Player nextPlayer= team.getPlayer(PlayerID);
					nextPlayer.Catch();
					round++;
					
					try {
						currentThread().sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
		}else {try {
			team.wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
	}
}
}}}
